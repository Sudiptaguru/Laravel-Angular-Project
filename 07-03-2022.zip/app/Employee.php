<?php

namespace App;
use DB;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    public $timestamps = false;
    protected $fillable = ['name', 'email', 'salary'];
    function getEmployee()
    {
        $data=DB::table('employees')->get();
        // dd($data);
        return $data;
    }
    function addEmployee($data)
    {
        DB::table('employees')->insert($data);
        // dd($data);
    }
}
