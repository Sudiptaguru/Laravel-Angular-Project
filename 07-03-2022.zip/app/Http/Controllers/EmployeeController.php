<?php

namespace App\Http\Controllers;
use App\Http\Controllers;
use App\Employee;

use Illuminate\Http\Request;

class EmployeeController extends Controller
{
    function getEmployee()
    {
        // return view("hello");
        $employeeModel=new Employee();
        $data=$employeeModel->getEmployee();
        return response()->json($data);
    }

    function addEmployee(Request $request)
    {
        // return view("hello");
        $employeeModel=new Employee();
        $data=$employeeModel->addEmployee($request->all());
    }

    function getEmployeeById($id)
    {
        $employee = Employee::find($id);
        if(is_null($employee)){
            return response()->json(['message'=>'Employee not found'], 404);
        }
        return response()->json($employee, 200);
    }

    public function updateEmployee(Request $request, $id){
        $employee = Empoyee::find($id);
        if(is_null($employee)){
            return response()->json(['message'=>'Employee not found'], 404);
        }
        $employee->update($request->all());
        return response()->json($employee, 200);
    }
}
