<?php

namespace App;
use DB;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    function getEmployee()
    {
        $data=DB::table('employee')->get();
        // dd($data);
        return $data;
    }
}
