import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  data:any;
  constructor(
    // private DataService:DataService
  ) { }
  getData()
  {
    return this.data=[
      {
        "name":"Sudipta",
      },
      {
        "name":"Sudip",
      }
    ]
  }
}
