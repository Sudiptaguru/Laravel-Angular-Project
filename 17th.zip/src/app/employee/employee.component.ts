import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';
import { Employee } from './employee.module';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css'],

})
export class EmployeeComponent implements OnInit {
  dataArr:any;
  employee=new Employee();
  constructor(
    private dataService:DataService
  ) { }

  ngOnInit() {
    this.getEmployeeData();
  }

  getEmployeeData()
  {
    // console.log("Hello");
    this.dataService.getData().subscribe(res=>{
      // console.log(res);
      this.dataArr=res;
    });
  }

  insertData()
  {
    this.dataService.insertData(this.employee).subscribe(res=>{
      // console.log(res);
      this.getEmployeeData();
    });
    // console.log("hello");
    // console.log(this.employee);
  }

}
